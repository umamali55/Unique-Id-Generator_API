package com.uniqueid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniqueIdGeneratorApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniqueIdGeneratorApiApplication.class, args);
	}

}

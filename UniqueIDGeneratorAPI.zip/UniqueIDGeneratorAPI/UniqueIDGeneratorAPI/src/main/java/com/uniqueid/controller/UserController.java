package com.uniqueid.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uniqueid.model.User;
import com.uniqueid.repository.UserRepository;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserRepository userRepository;

    @PostMapping("/register")
    public User registerUser(@RequestBody User user) {
    	//user.setId(UUID.randomUUID());
        return userRepository.save(user);
    }
    
    @GetMapping("/get") 
    public List<User> getAllUser()
    { 
    	return userRepository.findAll(); 
    }
    		  
     @GetMapping("/{id}") 
     public User getUserById(@PathVariable int id) { 
       return userRepository.findById(id).orElse(null);
     }
    		  
    
}


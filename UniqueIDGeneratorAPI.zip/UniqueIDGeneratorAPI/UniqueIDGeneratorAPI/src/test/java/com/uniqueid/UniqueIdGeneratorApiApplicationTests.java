package com.uniqueid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniqueIdGeneratorApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
